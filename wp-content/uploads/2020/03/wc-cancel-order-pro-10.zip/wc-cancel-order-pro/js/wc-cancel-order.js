function getParamByName(name,url){
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}

jQuery(function($){

        if(wc_cancel.wcc_confirmation){
            $('a.wc-cancel-order').click(function(e){
                e.stopPropagation();
                e.preventDefault();
            if(wc_cancel.wcc_reason){
                    var order_id = getParamByName('order_id',$(this).attr('href'));
                    var html = '<div id="wcc_reason">\
                    <div class="wcc_reason_inner">\
                    <div class="wcc-container">\
                    <div class="wcc_reason_label">'+wc_cancel.wcc_head+'<span> *</span></div>\
                    <textarea id="wcc_reason_text"></textarea>\
                    <div class="wcc_submit_outter">\
                    <button class="wcc_reason_submit" id="'+order_id+'" type="button">'+wc_cancel.wcc_button+'</button>\
                    </div>\
                    </div>\
                    <div class="wcc-loader"></div>'+wc_cancel.wcc_nonce+'</div>\
                    </div>';
                    $.fancybox.open(html);
                }
        });
        }

        $(document).on("click", ".wcc_reason_submit",function(){

            var reason_text = $('.fancybox-inner').find('#wcc_reason_text').val()
            if(reason_text==''){
                $('.fancybox-inner').find('#wcc_reason_text').css('border','1px solid #FF0000');
                return false;
            }

            $('#wcc_reason_text').css('border','none');
            $('.wcc-container').slideUp('slow');
            $('.wcc-loader').html('<img src="'+wc_cancel.wcc_loader+'">');
            jQuery.ajax({
                type	: "POST",
                cache	: false,
                url     : wc_cancel.wcc_ajax,
                dataType : 'json',
                data: {
                    'action' : 'cancellation_req',
                    'order_id' : $(this).attr('id'),
                    'cancellation_reason' : reason_text,
                    'wcc_cancel' : $('.fancybox-inner').find('#wcc_cancel').val()
                },
                success: function(data) {

                    $('.wcc-loader').html('<div class="wcc-loader-text">'+wc_cancel.wcc_confirmation_msg+'</div>');
                    setTimeout(function(){
                        if(data.redirect){
                            window.location.reload(true);
                        }
                    },2000);

                }
            });

        });

});