<?php
class WC_Cancel_Settings {

    /**
     * Bootstraps the class and hooks required actions & filters.
     *
     */

    public static function init() {
        add_filter( 'woocommerce_settings_tabs_array', __CLASS__ . '::add_settings_tab', 50 );
        add_action( 'woocommerce_settings_tabs_wc_cancel_settings', __CLASS__ . '::settings_tab' );
        add_action( 'woocommerce_update_options_wc_cancel_settings', __CLASS__ . '::update_settings' );
    }


    /**
     * Add a new settings tab to the WooCommerce settings tabs array.
     *
     * @param array $settings_tabs Array of WooCommerce setting tabs & their labels, excluding the Subscription tab.
     * @return array $settings_tabs Array of WooCommerce setting tabs & their labels, including the Subscription tab.
     */
    public static function add_settings_tab( $settings_tabs ) {
        $settings_tabs['wc_cancel_settings'] = __( 'WC Cancel', 'wc-cancel-order' );
        return $settings_tabs;
    }


    /**
     * Uses the WooCommerce admin fields API to output settings via the @see woocommerce_admin_fields() function.
     *
     * @uses woocommerce_admin_fields()
     * @uses self::get_settings()
     */
    public static function settings_tab() {
        woocommerce_admin_fields( self::get_settings() );
    }


    /**
     * Uses the WooCommerce options API to save settings via the @see woocommerce_update_options() function.
     *
     * @uses woocommerce_update_options()
     * @uses self::get_settings()
     */
    public static function update_settings() {
        woocommerce_update_options( self::get_settings() );
    }


    /**
     * Get all the settings for this plugin for @see woocommerce_admin_fields() function.
     *
     * @return array Array of settings for @see woocommerce_admin_fields() function.
     */

    public static function get_settings() {

        $statuses = wc_get_order_statuses();
        //echo '<pre>'; print_r($statuses); echo '</pre>';
        unset($statuses['wc-cancel-request'],$statuses['wc-cancelled'],$statuses['wc-refunded']);

        $settings = array(
            'section_title' => array(
                'name'     => __('Wc Cancel Order Settings','wc-cancel-order'),
                'type'     => 'title',
                'desc'     => '',
                'id'       => 'wc_cancel_settings_section_title'
            ),
            'confirm' => array(
                'title'   => __('Ask cancellation reason','wc-cancel-order'),
                'desc'    => __('Cancellation Reason', 'wc-cancel-order' ),
                'id'      => 'wc_cancel_settings_confirmation',
                'type'    => 'checkbox',
                'default' => 'yes',
            ),
            'direct_cancel' => array(
                'title'   => __('Allow cancellation from my account','wc-cancel-order'),
                'desc'    => __('Allow Customer to cancel order in my account.', 'wc-cancel-order' ),
                'id'      => 'wc_cancel_settings_direct_cancel',
                'type'    => 'checkbox',
                'default' => 'no',
            ),
            'hide_button' => array(
                'title'    => __('Hide Cancel Button', 'wc-cancel-order' ),
                'desc'     => '<p>'.__('Hide Cancel Button in selected status(s)', 'wc-cancel-order' ).'</p>',
                'id'       => 'wc_cancel_settings_hide_button',
                'default'  => 'wc-completed',
                'type'     => 'multiselect',
                'placeholder' => 'Select Status',
                'class'    => 'wc-enhanced-select',
                'options'  => $statuses,
            ),
            'hide_after' => array(
                'title' => __('Hide Cancel Button', 'wc-cancel-order' ),
                'desc' => __('After Order time (Set 0 to disable it)', 'wc-cancel-order' ),
                'type' => 'hide_after',
                'id' => 'hide_after_time'
            ),
            'section_end' => array(
                'type' => 'sectionend',
                'id' => 'wc_cancel_settings_section_end'
            )
        );

        return apply_filters( 'wc_cancel_settings', $settings );
    }

}
WC_Cancel_Settings::init();
?>